<?php
return array (
  'host' => '',
  'key' => '',
);
?>