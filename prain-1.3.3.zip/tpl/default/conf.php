<?php
return array (
	'id' => 'default',
	'type' => 'tpl',
	'author' => '雪洛',
	'name' => '默认主题',
	'intro' => '官网默认主题。',
	'price' => 0,
	'home' => 'https://xueluo.cn',
	'version' => '1.1.0',
	'limit' => '1.2.0'
);
?>