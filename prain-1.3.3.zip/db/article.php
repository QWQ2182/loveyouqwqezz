<?php
return array (
  'about' => 
  array (
    'id' => 'about',
    'cid' => 'default',
    'path' => 'article/about',
    'title' => '关于本站',
    'intro' => '',
    'img' => '',
    'time' => 1682065817,
    'updateTime' => 1682065817,
    'createTime' => 1682065817,
    'isTop' => 0,
    'isPrivate' => 0,
    'isComment' => 0,
    'isFk' => 1,
    'views' => 0,
    'comments' => 0,
    'tag' => 
    array (
      0 => '默认',
    ),
  ),
  'message' => 
  array (
    'id' => 'message',
    'cid' => 'default',
	  'path' => 'article/message',
    'title' => '留言板',
    'intro' => '',
    'img' => '',
    'time' => 1682065817,
    'updateTime' => 1682065817,
    'createTime' => 1682065817,
    'isTop' => 0,
    'isPrivate' => 0,
    'isComment' => 1,
    'isFk' => 1,
    'views' => 0,
    'comments' => 0,
    'tag' => 
    array (
      0 => '默认',
    ),
  ),
);
?>